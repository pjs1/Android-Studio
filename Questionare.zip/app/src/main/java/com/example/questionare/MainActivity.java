package com.example.questionare;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private Spinner province,city;
    private Button ok;
    private EditText name,password,suggest;
    private ArrayList<CheckBox> favs;
    private CheckBox mooc,dingding,lanmo,xueersi;
    private RadioGroup masterylevel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.ok=(Button)findViewById(R.id.OK);
        this.name = (EditText)findViewById(R.id.username);
        this.password=(EditText)findViewById(R.id.password);
        this.mooc=(CheckBox)findViewById(R.id.mooc);
        this.dingding=(CheckBox)findViewById(R.id.dingding);
        this.lanmo=(CheckBox)findViewById(R.id.lanmo);
        this.xueersi=(CheckBox)findViewById(R.id.xueersi);
        this.masterylevel=(RadioGroup)findViewById(R.id.masterylevel);
        this.suggest=(EditText)findViewById(R.id.suggest);
        favs = new ArrayList<CheckBox>();
        //将各项爱好对象存入数组
        favs.add(mooc);
        favs.add(dingding);
        favs.add(lanmo);
        favs.add(xueersi);
        //省市联动
        this.province=(Spinner)findViewById(R.id.province);
        this.city=(Spinner)findViewById(R.id.city);
        final String[] city_beijing = {"-城市-","北京市"};
        final  String[] city_tianjin = {"-城市-","天津市"};
        final  String[] city_shanghai = {"-城市-","上海市"};
        final  String[] city_chongqin = {"-城市-","重庆市"};
        final  String[] city_xinjiang = {"-城市-","乌鲁木齐","石河子","阿拉尔市","图木舒克","五家渠","哈密","吐鲁番","阿克苏","喀什","和田","伊宁","塔城","阿勒泰","奎屯","博乐","昌吉","阜康","库尔勒","阿图什","乌苏"};
        final  String[] city_xizhang = {"-城市-","拉萨","日喀则"};
        final  String[] city_ningxia = {"-城市-","银川","石嘴山","吴忠","固原","中卫","青铜峡市","灵武市"};
        final  String[] city_neimengu = {"-城市-","呼和浩特","包头","乌海","赤峰","通辽","鄂尔多斯","呼伦贝尔","巴彦淖尔","乌兰察布","霍林郭勒市","满洲里市","牙克石市","扎兰屯市","根河市","额尔古纳市","丰镇市","锡林浩特市","二连浩特市","乌兰浩特市","阿尔山市"};
        final  String[] city_guangxi = {"-城市-","南宁","柳州","桂林","梧州","北海","崇左","来宾","贺州","玉林","百色","河池","钦州","防城港","贵港","岑溪","凭祥","合山","北流","宜州","东兴","桂平"};
        final  String[] city_heilongjiang ={"-城市-","哈尔滨","大庆","齐齐哈尔","佳木斯","鸡西","鹤岗","双鸭山","牡丹江","伊春","七台河","黑河","绥化","五常","双城","尚志","纳河","密山","铁力","同江","富锦","绥芬河","海林","宁安","穆林","北安","五大连池","肇东","海伦","安达"};
        final  String[] city_jiangsu = {"-城市-","南京","镇江","常州","无锡","苏州","徐州","连云港","淮安","盐城","扬州","泰州","南通","宿迁"};
        final  String[] city_anhui = {"-城市-","合肥","蚌埠","芜湖","淮南","亳州","阜阳","淮北","宿州","滁州","安庆","巢湖","马鞍山","宣城","黄山","池州","铜陵"};
        final  String[] city_zhejiang = {"-城市-","杭州","嘉兴","湖州","宁波","金华","温州","丽水","绍兴","衢州","舟山","台州"};
        final  String[] city_jilin = {"-城市-","长春","吉林","四平","辽源","通化","白山","松原","白城"};
        final  String[] city_liaoning = {"-城市-","沈阳","大连","鞍山","抚顺","本溪","丹东","锦州","营口","阜新","辽阳","盘锦","铁岭","朝阳","葫芦岛"};
        final  String[] city_hebei = {"-城市-","石家庄","唐山","邯郸","秦皇岛","保定","张家口","承德","廊坊","沧州","衡水","邢台"};
        final  String[] city_shandong = {"-城市-","济南","青岛","淄博","枣庄","东营","烟台","潍坊","济宁","泰安","威海","日照","莱芜","临沂","德州","聊城","菏泽","滨州"};
        final  String[] city_qita = {"-城市-","后续添加中"};

        province.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String result = province.getSelectedItem().toString();
                Toast.makeText(MainActivity.this,result,Toast.LENGTH_LONG).show();
                //System.out.println(result);
                if(result.equals("北京市"))
                {
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_dropdown_item_1line,android.R.id.text1,city_beijing);
                    city.setAdapter(adapter);
                }
                else if(result.equals("天津市"))
                {
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_dropdown_item_1line,android.R.id.text1,city_tianjin);
                    city.setAdapter(adapter);
                }
                else if(result.equals("上海市"))
                {
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_dropdown_item_1line,android.R.id.text1,city_shanghai);
                    city.setAdapter(adapter);
                }
                else if(result.equals("重庆市"))
                {
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_dropdown_item_1line,android.R.id.text1,city_chongqin);
                    city.setAdapter(adapter);
                }
                else if(result.equals("新疆"))
                {
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_dropdown_item_1line,android.R.id.text1,city_xinjiang);
                    city.setAdapter(adapter);
                }
                else if(result.equals("西藏"))
                {
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_dropdown_item_1line,android.R.id.text1,city_xizhang);
                    city.setAdapter(adapter);
                }
                else if(result.equals("宁夏"))
                {
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_dropdown_item_1line,android.R.id.text1,city_ningxia);
                    city.setAdapter(adapter);
                }
                else if(result.equals("内蒙古"))
                {
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_dropdown_item_1line,android.R.id.text1,city_neimengu);
                    city.setAdapter(adapter);
                }
                else if(result.equals("广西省"))
                {
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_dropdown_item_1line,android.R.id.text1,city_guangxi);
                    city.setAdapter(adapter);
                }
                else if(result.equals("黑龙江省"))
                {
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_dropdown_item_1line,android.R.id.text1,city_heilongjiang);
                    city.setAdapter(adapter);
                }
                else if(result.equals("吉林省"))
                {
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_dropdown_item_1line,android.R.id.text1,city_jilin);
                    city.setAdapter(adapter);
                }
                else if(result.equals("辽宁省"))
                {
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_dropdown_item_1line,android.R.id.text1,city_liaoning);
                    city.setAdapter(adapter);
                }
                else if(result.equals("河北省"))
                {
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_dropdown_item_1line,android.R.id.text1,city_hebei);
                    city.setAdapter(adapter);
                }
                else if(result.equals("山东省"))
                {
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_dropdown_item_1line,android.R.id.text1,city_shandong);
                    city.setAdapter(adapter);
                }
                else if(result.equals("江苏省"))
                {
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_dropdown_item_1line,android.R.id.text1,city_jiangsu);
                    city.setAdapter(adapter);
                }
                else if(result.equals("安徽省"))
                {
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_dropdown_item_1line,android.R.id.text1,city_anhui);
                    city.setAdapter(adapter);
                }
                else if(result.equals("浙江省"))
                {
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_dropdown_item_1line,android.R.id.text1,city_zhejiang);
                    city.setAdapter(adapter);
                }
                else
                {
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_dropdown_item_1line,android.R.id.text1,city_qita);
                    city.setAdapter(adapter);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }
    //确认键监听
    public void ShowAlertDialog (View view)
    {
        //先检查是否填写都符合要求
            if(IsChecked()==1)
            {
                //在警告提示框，确认提交
                AlertDialog alert = new AlertDialog.Builder(MainActivity.this).create();
                alert.setMessage("确认提交嘛？");
                //确认提交，跳转到第二个界面
                alert.setButton(DialogInterface.BUTTON_POSITIVE, "确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(MainActivity.this,"确认提交",Toast.LENGTH_SHORT).show();
                        StringBuilder sb = new StringBuilder();
                        sb.append("用户名:"+name.getText().toString()+"\n");
                        sb.append("所在省份："+province.getSelectedItem()+"\n");
                        sb.append("所在城市："+city.getSelectedItem()+"\n");
                        sb.append("使用的学习平台:"+getFavorite()+"\n");
                        if(GetRadioButtonId()==0)
                            sb.append("线上学习掌握程度：能听懂，掌握内容80%-100%\n");
                        else if(GetRadioButtonId()==1)
                            sb.append("线上学习掌握程度：能听懂，掌握内容60%-80%\n");
                        else
                            sb.append("线上学习掌握程度：听懂的内容少，50%以下\n");
                        sb.append("建议："+suggest.getText().toString()+"\n");
                        Toast.makeText(MainActivity.this,sb.toString(),Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent();
                        intent.setClass(MainActivity.this,SecondActivity.class);
                        intent.putExtra("info",sb.toString());
                        startActivity(intent);
                    }
                });
                //取消提交，继续修改
                alert.setButton(DialogInterface.BUTTON_NEGATIVE, "取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(MainActivity.this,"取消提交",Toast.LENGTH_SHORT).show();
                    }
                });
                alert.show();
            }

    }

    //用户名检查 不为空
    private int Checkname()
    {
        String na = name.getText().toString();
        if(na.isEmpty())
        {
            Toast.makeText(MainActivity.this,"用户名不能为空",Toast.LENGTH_SHORT).show();
            return 0;
        }
        return 1;
    }

    //密码检查 不为空，且长度>=8
    private int Checkpassword()
    {
        String na=password.getText().toString();
        if(na.isEmpty())
        {
            Toast.makeText(MainActivity.this,"密码不能为空",Toast.LENGTH_SHORT).show();
            return 0;
        }
        if(na.length()<8)
        {
            Toast.makeText(MainActivity.this,"密码长度不小于8",Toast.LENGTH_SHORT).show();
            return 0;
        }
        return 1;
    }

    //获取所用APP
    public String getFavorite(){
        String favo="";
        for(CheckBox cb : favs)
        {
            if(cb.isChecked())
            {
                favo += cb.getText().toString();
                favo+=",";
            }
        }
        return favo;
    }

    //获取所选的单选按钮序号，没选则返回0
    private int GetRadioButtonId(){
        int i;
        int count=masterylevel.getChildCount();//获取radiogroup中子组件数目（radiobutton）
        for( i = 0 ;i < count; i++)// 按钮顺序
        {
            RadioButton rb = (RadioButton)masterylevel.getChildAt(i);//根据索引获取当前索引对应的radioButton
            if(rb.isChecked())//检查是否被选中
            {
                return i;
            }
        }
        Toast.makeText(MainActivity.this,"请选择掌握程度",Toast.LENGTH_SHORT).show();
        return -1;//没有被选中的
    }

    //判断建议不为空
    private int Checksuggest()
    {
        String na = suggest.getText().toString();
        if(na.isEmpty())
        {
            Toast.makeText(MainActivity.this,"建议不能为空",Toast.LENGTH_SHORT).show();
            return 0;
        }
        return 1;
    }

    //判断多选框
    private int CheckCheckBox(){
        if((mooc.isChecked())||(dingding.isChecked())||(xueersi.isChecked())||(lanmo.isChecked()))
            return 1;
        else
        {
            Toast.makeText(MainActivity.this,"请选择所用平台APP",Toast.LENGTH_SHORT).show();
            return 0;
        }
    }

    //总的判断函数
    private int IsChecked( )
    {
        if((Checkname()==1)&&(Checkpassword()==1)&&(GetRadioButtonId()!=-1)&&(Checksuggest()==1)&&(CheckCheckBox()==1))
            return 1;
        return 0;
    }
}
